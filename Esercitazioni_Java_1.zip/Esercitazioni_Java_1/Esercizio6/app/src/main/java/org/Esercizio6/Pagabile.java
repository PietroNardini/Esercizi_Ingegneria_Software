package org.Esercizio6;

public interface Pagabile {
    void effettuaPagamento(double importo) throws Exception;
}
