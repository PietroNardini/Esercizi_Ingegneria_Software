package org.Esercizio3;

public interface Animale {
        public void emettiVerso();
        public void muoviti();
}
