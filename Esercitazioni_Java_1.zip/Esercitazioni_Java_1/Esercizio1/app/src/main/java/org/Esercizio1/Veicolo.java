package org.Esercizio1;

public interface Veicolo {
        public void avvia();
        public void ferma();
        public String getTipo();

}
