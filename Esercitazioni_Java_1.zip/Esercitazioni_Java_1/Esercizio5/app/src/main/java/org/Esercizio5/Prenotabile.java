package org.Esercizio5;

public interface Prenotabile {
    public void prenota();

}
